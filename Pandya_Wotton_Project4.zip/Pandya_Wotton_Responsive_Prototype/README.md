# Responsive Prototype 

## Description
This project takes the homepage of Billy Beer and creates a scaffold that uses responisve design emphasizing mobile-first.\

## Credits
Dev Pandya & Aiden Wotton

## License
MIT